使用方法：
1. 把你的瓦片文件夹放进这个文件夹里。
2. 瓦片文件夹名称必须是：qgis tiles 02
3. 最终结构应为：
   map_embed_flower_distribution/
   ├─ index.html
   └─ qgis tiles 02/
      └─ z/x/y.png
4. 直接打开 index.html 即可。

本版本特性：
- 地图范围固定为你之前的同一矩形范围
- 缩小时不会再缩到看见范围外内容
- 四边白色遮罩为完全不透明
- 不显示点击弹窗
- 适合直接嵌入总项目网页
